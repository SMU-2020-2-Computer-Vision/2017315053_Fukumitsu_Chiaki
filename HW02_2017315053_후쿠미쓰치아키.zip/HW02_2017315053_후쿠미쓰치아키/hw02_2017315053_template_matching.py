import cv2
import numpy as np
from matplotlib import pyplot as plt

def template_matching(img_template, img_refrence):
    w, h = img_template.shape[::-1]
    img_gray = cv2.cvtColor(img_refrence, cv2.COLOR_BGR2GRAY)

    #Scaling
    img_res = cv2.resize(img_template, None, fx = w, fy = h, interpolation = cv2.INTER_CUBIC)

    #Rotation
    # for i in range(0,361,10):
    #     M = cv2.getRotationMatrix2D((h/2,w/2),i, 1)
    #     img_refrence = cv2.warpAffine(img_template,M ,(h, w))

    # Apply template matching
    res = cv2.matchTemplate(img_gray, img_template, cv2.TM_CCOEFF_NORMED)
    threshold = 0.6
    loc = np.where(res >= threshold)

    # Draw a bounding box
    img_res = img_refrence.copy()
    for pt in zip(*loc[::-1]):
        cv2.rectangle(img_res, pt, (pt[0] + w, pt[1] + h), (0,0,255), 2)

    cv2.imshow("Find fish", img_res)



